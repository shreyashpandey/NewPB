const formData = {
  name: "",
  email: "",
  designation: "",
  about: "",
  WorkExperience: [
    {
      ProfileName: "",
      From: "",
      To: "",
      Description: "",
    },
  ],
  Projects: [
    {
      ProjectName: "",
      Description: "",
    },
  ],
  Certifications: [
    {
      From: "",
      To: "",
      CertificationName: "",
      CertificationURL: "",
    },
  ],
  Links: [
    {
      LinkName: "",
      LinkURL: "",
    },
  ],
};
export default formData;
