// YourReactComponent.js

import React from "react";
import App from "./App";
// import { downloadHtml } from "./download"; // Import the download function
import ReactDOMServer from "react-dom/server";

const YourReactComponent = () => {
  

  return (
    
  );
};

export default YourReactComponent;
