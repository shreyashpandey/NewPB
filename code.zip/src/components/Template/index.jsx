import HtmlContent from "./HtmlContent";
import App from "./App";

export default function Template(){

  return (
    <>
      <HtmlContent />
      <App />
    </>
  )

}