import * as React from 'react';
import Box from '@mui/material/Box';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Grid from "@mui/material/Grid";
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Forms from "../Forms"
import Template from '../Template';
import { Context } from '../Context';
import { useContext, useState } from 'react';
import Alert from '@mui/material/Alert';
import Stack from '@mui/material/Stack';
const steps = ['Select Template', 'Configure Values', 'Generate Portfolio'];

export default function HorizontalLinearStepper() {
  const [activeStep, setActiveStep] = React.useState(0);
  const [skipped, setSkipped] = React.useState(new Set());
  const { template, setTemplate } = useContext(Context);
  const [cardStyle, setCardStyle] = useState({});
  const [toggleCard, setToggleCard] = useState({});
  const [error, setError] = useState("");
  const isStepOptional = (step) => {
    return step === 1;
  };

  const isStepSkipped = (step) => {
    return skipped.has(step);
  };

  const handleNext = () => {
    if (template.length == 0) {
      setError("Template Not selected");
    }
    else {
      setError("");
      let newSkipped = skipped;
      if (isStepSkipped(activeStep)) {
        newSkipped = new Set(newSkipped.values());
        newSkipped.delete(activeStep);
      }
      setActiveStep((prevActiveStep) => prevActiveStep + 1);
      setSkipped(newSkipped);
    }
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleSkip = () => {
    if (!isStepOptional(activeStep)) {
      // You probably want to guard against something like this,
      // it should never occur unless someone's actively trying to break something.
      throw new Error("You can't skip a step that isn't optional.");
    }

    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setSkipped((prevSkipped) => {
      const newSkipped = new Set(prevSkipped.values());
      newSkipped.add(activeStep);
      return newSkipped;
    });
  };
  const selectedTemplate = (e) => {
    const { target: { id } } = e;
    let cards = cardStyle;
    let toggles = toggleCard;
    toggles[id] = !toggles[id];
    if (toggleCard[id]) {
      cards[id] = { border: "2px solid black" };
      setTemplate(id);
    }
    else {
      cards[id] = { border: "0px solid black" };
      setTemplate("");
    }
    setToggleCard(toggles)
    setCardStyle(cards);
  }
  const handleReset = () => {
    setActiveStep(0);
  };

  return (
    <>
      {
        error.length > 0 ? (
          <Stack sx={{ width: '100%' }} spacing={2}>
            <Alert severity="error">{error}</Alert>
          </Stack>
        ) : <></>
      }
      <Box sx={{ width: '100%',border:'2px solid gray',padding:'20px' }}>
        <Stepper activeStep={activeStep}>
          {steps.map((label, index) => {
            const stepProps = {};
            const labelProps = {};
            if (isStepOptional(index)) {
              labelProps.optional = (
                <Typography variant="caption">Optional</Typography>
              );
            }
            if (isStepSkipped(index)) {
              stepProps.completed = false;
            }
            return (
              <Step key={label} {...stepProps}>
                <StepLabel {...labelProps}>{label}</StepLabel>
              </Step>
            );
          })}
        </Stepper>
        {activeStep === steps.length ? (
          <React.Fragment>
            <Typography sx={{ mt: 2, mb: 1 }}>
              All steps completed - you&apos;re finished
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Box sx={{ flex: '1 1 auto' }} />
              <Button onClick={handleReset}>Reset</Button>
            </Box>
          </React.Fragment>
        ) : (
          <React.Fragment>
            {
              activeStep == 0 ? (
                <>
                  <Typography sx={{ mt: 2, mb: 1 }}>Templates</Typography>
                  <Grid container spacing={4}>
                    <Grid item xs={12} sm={4} md={4}>
                      <Card id={"template1"} sx={{ minWidth: "230px", minHeight: '250px', boxShadow: "0px 2px 1px -1px rgba(0,170,90,11.9), 0px 1px 1px 0px rgba(0,0,0,0.14), 10px 1px 3px 10px rgba(0,0,0,0.12)" }} onClick={selectedTemplate} style={cardStyle.template1}>
                        <CardContent>
                          <Typography gutterBottom variant="h5" component="div">
                            Template1
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid item xs={12} sm={4} md={4}>
                      <Card id={"template2"} sx={{ minWidth: "230px", minHeight: '250px', boxShadow: "0px 2px 1px -1px rgba(0,170,90,11.9), 0px 1px 1px 0px rgba(0,0,0,0.14), 10px 1px 3px 10px rgba(0,0,0,0.12)" }} onClick={selectedTemplate} style={cardStyle.template2}>
                        <CardContent>
                          <Typography gutterBottom variant="h5" component="div">
                            Template2
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                    <Grid item xs={12} sm={4} md={4}>
                      <Card id={"template3"} sx={{ minWidth: "230px", minHeight: '250px', boxShadow: "0px 2px 1px -1px rgba(0,170,90,11.9), 0px 1px 1px 0px rgba(0,0,0,0.14), 10px 1px 3px 10px rgba(0,0,0,0.12)" }} onClick={selectedTemplate} style={cardStyle.template3}>
                        <CardContent>
                          <Typography gutterBottom variant="h5" component="div">
                            Template3
                          </Typography>
                        </CardContent>
                      </Card>
                    </Grid>
                  </Grid>

                </>) : (<></>)

            }
            {
              activeStep == 1 ? (
                <>
                  <Typography sx={{ mt: 2, mb: 1 }}>Step {activeStep + 1}</Typography>
                  <Forms />
                </>) : (<></>)
            }
            {
              activeStep == 2 ? (
                <>
                  <Typography sx={{ mt: 2, mb: 1 }}>Step {activeStep + 1}</Typography>
                  <Template />
                </>) : (<></>)
            }
            <Box sx={{ display: 'flex', flexDirection: 'row', pt: 2 }}>
              <Button
                color="inherit"
                disabled={activeStep === 0}
                onClick={handleBack}
                sx={{ mr: 1 }}
              >
                Back
              </Button>
              <Box sx={{ flex: '1 1 auto' }} />
              {isStepOptional(activeStep) && (
                <Button color="inherit" onClick={handleSkip} sx={{ mr: 1 }}>
                  Skip
                </Button>
              )}

              <Button onClick={handleNext}>
                {activeStep === steps.length - 1 ? 'Finish' : 'Next'}
              </Button>
            </Box>
          </React.Fragment>
        )}
      </Box>
    </>
  );
}