import React, { useState } from "react";

export const Context = React.createContext();
export const ContextProvider = ({ children }) => {
    const [template, setTemplate] = useState("");
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [about, setAbout] = useState("");
    const [address, setAddress] = useState("");
    const [workExperience, setWorkExperience] = useState([{ "ProfileName": "", "Description": "", "From": "", "To": "" }]);
    const [projects, setProjects] = useState([{ "ProjectName": "", "Description": "", "GitHub/Bitbucket Url": "", "ProjectURL": "" }]);
    const [skills, setSkills] = useState([]);
    const [certifications, setCertifications] = useState([{ "CertificationName": "", "CertificationId": "", "Description": "" }])


    return (
        <Context.Provider value={{ template, setTemplate, name, setName, email, setEmail, phone, setPhone, about, setAbout, address, setAddress, workExperience, setWorkExperience, projects, setProjects, skills, setSkills, certifications, setCertifications }}>
            {children}
        </Context.Provider>
    );
};