import { useState } from 'react'
import './App.css'
import CustomizedSteppers from "./components/Stepper"
import { ContextProvider } from './components/Context'
function App() {
  return (
    <ContextProvider>
    <div>
      <CustomizedSteppers/>
    </div>
    </ContextProvider>
  )
}

export default App
